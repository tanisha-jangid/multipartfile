package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.MultiPartFileEntity;
import com.example.demo.repository.MultipartRepo;

@Service
public class MultiPartServiceImpl implements MultipartService {

    @Autowired
    MultipartRepo repo;
    @Override
    public List<MultiPartFileEntity> getAllFiles() {
        Iterable<MultiPartFileEntity> entites=repo.findAll();
        return (List<MultiPartFileEntity>) entites;
      }

    @Override
    public void saveAllFileList(List<MultiPartFileEntity> fileList) {
        for(MultiPartFileEntity ent:fileList){
            repo.save(ent);
        }
    }

    @Override
    public void deleteFiles() {

        repo.deleteAll();

       
    }
    
}
