package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Value;


@Entity
public class MultiPartFileEntity {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Value("1")
     long id;
     String fileName;
     String content;
    private String fileType;

    
    
    public MultiPartFileEntity() {
    }
    public MultiPartFileEntity( String fileName, String content, String fileType) {
        //this.id = id;
        this.fileName = fileName;
        this.content = content;
        this.fileType = fileType;
    }
    
    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public String getFileType() {
        return fileType;
    }
    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    

}
