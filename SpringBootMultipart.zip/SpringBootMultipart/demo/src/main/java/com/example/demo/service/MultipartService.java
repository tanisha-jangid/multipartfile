package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.MultiPartFileEntity;

//import antlr.collections.List;

public interface MultipartService {
    List<MultiPartFileEntity> getAllFiles();
    void saveAllFileList(List<MultiPartFileEntity> fileList);
    void deleteFiles();
}
