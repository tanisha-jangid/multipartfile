package com.example.demo.controller;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.entity.MultiPartFileEntity;
import com.example.demo.service.MultiPartServiceImpl;

@RestController
public class MultiPartFileController {
    @Autowired
    MultiPartServiceImpl service;

    @PostMapping("/upload-file")
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile[] file){

        try{
        List<MultiPartFileEntity> list=new ArrayList<MultiPartFileEntity>();
        for(MultipartFile files:file){
        String fileContentType=files.getContentType();
        String fileName=files.getOriginalFilename();
        String sourceFileContent=new String(files.getBytes(),StandardCharsets.UTF_8);
        MultiPartFileEntity entity=new MultiPartFileEntity(fileName, fileContentType, sourceFileContent);
        list.add(entity);
        }
        service.saveAllFileList(list);
    }
        catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
       // modal.addAttribute("allFiles", service.getAllFiles());

    
        return ResponseEntity.ok("working");
    }

    @GetMapping("/getAllDetails")
    public ResponseEntity<List<MultiPartFileEntity>> getAllDetailsFiles(){
        List<MultiPartFileEntity> list=service.getAllFiles();
        return new ResponseEntity<List<MultiPartFileEntity>>(list,HttpStatus.OK);
    }

    @DeleteMapping("/deleteAllDetails")
    public ResponseEntity<String> deleteDetailsFiles(){
        service.deleteFiles();
        return ResponseEntity.ok("deleted successfully");
    }

    
}
